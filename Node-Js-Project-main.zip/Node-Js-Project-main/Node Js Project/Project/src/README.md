Please follow these below steps to run on localhost

For Client
1. cd client
2. npm install
3. npm start

For Server
1. cd server
2. npm install
3. node app.js
