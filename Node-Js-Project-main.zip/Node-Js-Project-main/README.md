# Node-Js-Project
Created a Node.js Api which register a new user, who can add new orders, and get order details of that user.
